## To store fonts

How to contribute more fonts - create a pull req or leave the font link as an issue or comment.
Or just send it via telegram to [TeleBot Chat](https://t.me/TeleBotHelpChat) group!

(c) 2020 TeleBot
